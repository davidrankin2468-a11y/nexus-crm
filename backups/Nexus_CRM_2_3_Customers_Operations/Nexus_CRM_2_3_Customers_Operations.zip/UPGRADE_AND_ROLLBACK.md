# Nexus CRM 1.4 — safe installation
1. Close CRM 1.3. Keep its original folder unchanged.
2. Copy the **entire** CRM 1.3 folder to a separate offline backup location.
3. Extract 1.4 into a new folder.
4. Copy your existing `data/` directory into the new 1.4 folder (including `.session_key` and `logos/`).
5. Run `start_windows.bat` from the new folder. Test login, Customers, Jobs, Estimates, Invoices, Users, Security, and Backup.
6. If there is a problem, stop 1.4 and relaunch the untouched 1.3 folder.
7. Never run 1.3 and 1.4 against the same live SQLite database.
`verify_update.py` validates a SHA-256 provided separately from the ZIP, but does not authenticate a publisher.
Your real laptop database is not included in this distribution ZIP.
