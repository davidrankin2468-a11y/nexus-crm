# Nexus CRM 1.6 — Windows 11 installation
1. Stop the 1.5.1 server (Ctrl+C in its command window).
2. Keep the entire 1.5.1 folder untouched as a rollback copy.
3. Extract this ZIP into a new folder: `Documents\Nexus CRM\Nexus CRM 1.6`.
4. Run `start_windows.bat`. The launcher reuses `%LOCALAPPDATA%\NexusCRM\data` and does not require a new administrator account.
5. Confirm login, Maintenance, Permissions, and your existing features.
6. If it fails, stop 1.6 and reopen 1.5.1. Do not delete `%LOCALAPPDATA%\NexusCRM`.

The launcher attempts a SQLite backup to `%LOCALAPPDATA%\NexusCRM\backups\pre_upgrade_1_6.sqlite3` before database migrations. Confirm the backup in Maintenance or on disk. Do not run two versions simultaneously.
