
"""Offline integrity check for a downloaded ZIP and its separately supplied SHA256."""
import hashlib, sys, zipfile
from pathlib import Path
if __name__=='__main__':
    if len(sys.argv)!=3:
        raise SystemExit('Usage: py verify_update.py PACKAGE.zip EXPECTED_SHA256')
    p=Path(sys.argv[1]);expected=sys.argv[2].strip().lower()
    if len(expected)!=64 or any(c not in '0123456789abcdef' for c in expected):
        raise SystemExit('Invalid expected SHA-256')
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    if actual!=expected:raise SystemExit('FAILED: SHA-256 mismatch. Do not install.')
    with zipfile.ZipFile(p) as z:
        if z.testzip():raise SystemExit('FAILED: damaged ZIP.')
        for n in z.namelist():
            pp=Path(n)
            if pp.is_absolute() or '..' in pp.parts:raise SystemExit('FAILED: unsafe ZIP path')
    print('Verified checksum, archive integrity and entry paths. Not a signature or publisher authentication.')
