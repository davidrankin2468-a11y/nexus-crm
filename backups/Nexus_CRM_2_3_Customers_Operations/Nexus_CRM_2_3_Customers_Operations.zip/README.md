# Nexus CRM 2.3 — Customer and Operations Upgrade

**Based on the working code package in Nexus CRM 2.2 Five-Tab UI.**

## Five main tabs
Dashboard · Customers · Operations · Finance · Management. No additional main tabs were added.

## New in 2.3
- Dashboard displays the real company-scoped number of customers and open jobs, paid-invoice totals and unpaid-invoice totals, plus recent jobs.
- Customers: add records, search by name/email/phone, edit customer contact details and notes, view linked jobs.
- Operations / Jobs: create jobs with amount validation, filter by job status, change status inline; existing sync-outbox triggers record changes.
- All customer and job updates are scoped to the signed-in company; they use the existing sign-in/session and CSRF protections.
- A separate `pre_upgrade_2_3.sqlite3` SQLite snapshot is made before the launcher starts this version.
- Existing estimates, invoices, schedules, employees, reports, account controls, backup and local sync journal are retained.

## Not included
- No hosted cloud backend or working cloud sync.
- No connection between the Windows CRM database and the public Vercel design demo.
- No real customer records or passwords are bundled here.
- Invoice totals reflect recorded invoice status, not verified bank receipts.

## Windows 11 installation
1. Completely close your previous CRM version.
2. Keep the previous CRM folder and its backups unchanged.
3. Unzip this archive into a **new** folder, for example `Documents\Nexus CRM\Nexus CRM 2.3`.
4. Run `start_windows.bat` and sign in using the existing administrator account.
5. Check the five tabs, especially Customers and Operations.
6. If there is any problem, close 2.3 and reopen your previous CRM version.

**Do not delete or overwrite `%LOCALAPPDATA%\NexusCRM`** — it contains the database and account information. Backups contain sensitive records; store them privately.
