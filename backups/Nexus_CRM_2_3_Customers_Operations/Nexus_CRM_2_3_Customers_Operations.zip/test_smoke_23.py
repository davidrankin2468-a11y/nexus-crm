"""Basic route/database smoke test using a minimal Flask shim when Flask isn't installed.
Not a substitute for running on Windows with requirements installed.
"""
import os, sys, types, tempfile, re
from pathlib import Path

class FauxFlask:
 def __init__(self,*a,**k): self.config={};self.routes={};self.secret_key=None
 def route(self, path,**opts):
  def add(fn):
   if path in self.routes: raise AssertionError('Duplicate route '+path)
   self.routes[path]=fn
   return fn
  return add
 def before_request(self,fn):return fn
 def after_request(self,fn):return fn

class Request:
 method='GET';form={};args={};path='/';endpoint='home';remote_addr='127.0.0.1';files={}
request=Request();session={}
def abort(code,*a):raise RuntimeError('HTTP '+str(code)+' '+str(a))
def fake_render(txt,**kwargs):return txt.replace('{{csrf}}',kwargs['csrf'])
mock=types.ModuleType('flask')
for n,v in {'Flask':FauxFlask,'request':request,'session':session,'redirect':lambda p:('redirect',p),'render_template_string':fake_render,'flash':lambda *a:None,'send_file':lambda *a,**k:None,'abort':abort,'send_from_directory':lambda *a,**k:None,'jsonify':lambda v:v}.items():setattr(mock,n,v)
sys.modules['flask']=mock

with tempfile.TemporaryDirectory() as d:
 os.environ['NEXUS_CRM_DATA_DIR']=d
 sys.path.insert(0,str(Path(__file__).parent))
 import app
 assert len(app.app.routes)==28, len(app.app.routes)
 with app.conn() as db:
  company=db.execute('INSERT INTO companies(name) VALUES(?)',('Test Company',)).lastrowid
  salt='de'*16
  uid=db.execute("INSERT INTO users(company_id,username,salt,password_hash,role) VALUES(?,?,?,?,?)",(company,'test',salt,app.hashpw('testingpassword123',salt),'admin')).lastrowid
 session.update(company_id=company,user_id=uid)
 def req(path,method='GET',form=None,args=None):
  request.path=path;request.method=method;request.form=form or {};request.args=args or {};request.endpoint=path
 # Dashboard before mutations
 req('/');assert 'Customers' in app.home()
 # Create customer
 req('/customers','POST',{'name':'<Internal test>','email':'test@example.com','phone':'5551234','notes':'one'})
 assert app.customers()==('redirect','/customers')
 with app.conn() as db:
  cid=db.execute('SELECT id FROM customers WHERE company_id=?',(company,)).fetchone()['id']
 req('/customers');html=app.customers();assert '&lt;Internal test&gt;' in html and 'test@example.com' in html, html[-2400:]
 req('/customers',args={'q':'55512'});assert '1 customer(s)' in app.customers()
 req('/customers/'+str(cid)+'/edit','POST',{'name':'Acme New','email':'new@example.com','phone':'5550000','notes':'updated'})
 assert app.edit_customer(cid)==('redirect','/customers')
 # Jobs
 req('/jobs','POST',{'customer_id':str(cid),'title':'Outdoor Painting','amount':'199.95'})
 assert app.jobs()==('redirect','/jobs')
 req('/jobs');html=app.jobs();assert 'Outdoor Painting' in html and '$199.95' in html
 with app.conn() as db:
  jid=db.execute('SELECT id FROM jobs WHERE company_id=?',(company,)).fetchone()['id']
 req('/jobs/'+str(jid)+'/status','POST',{'status':'Completed'});assert app.job_status(jid)==('redirect','/jobs')
 req('/');html=app.home();assert '<div class="shell">' in html and 'Open jobs' in html and 'Acme New' in html
 with app.conn() as db:
  changes=db.execute('SELECT entity,operation FROM sync_outbox ORDER BY seq').fetchall()
  assert [(r['entity'],r['operation']) for r in changes]==[('customers','insert'),('customers','update'),('jobs','insert'),('jobs','update')]
  sec=db.execute('INSERT INTO companies(name) VALUES(?)',('Other Company',)).lastrowid
 session['company_id']=sec
 req('/customers');assert 'Acme New' not in app.customers()
 req('/jobs');assert 'Outdoor Painting' not in app.jobs()
 req('/customers/'+str(cid)+'/edit');
 try:app.edit_customer(cid);raise AssertionError('Tenant access allowed')
 except RuntimeError as e:assert '404' in str(e)
 print('PASS: registered routes:',len(app.app.routes),'customer CRUD, search, job create/status, tenant isolation, sync journal')
