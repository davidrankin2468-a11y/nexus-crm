
"""Deployment entrypoint for a TLS-terminating reverse proxy; not a production-ready multi-tenant service."""
import os
if os.environ.get('NEXUS_HTTPS')!='1':
    raise RuntimeError('Set NEXUS_HTTPS=1 only behind a correctly configured HTTPS reverse proxy')
if not os.environ.get('NEXUS_SECRET_KEY'):
    raise RuntimeError('NEXUS_SECRET_KEY required for deployment')
from waitress import serve
from app import app
if __name__=='__main__':
    serve(app,host='127.0.0.1',port=int(os.environ.get('PORT','8765')),threads=8)
