# Windows 11 installation — preserve your existing account

1. Close Nexus CRM 1.6 and stop its CMD server.
2. Keep your working 1.6 folder untouched as rollback.
3. Extract this ZIP to `Documents\Nexus CRM\Nexus CRM 2.0`.
4. Run `start_windows.bat` in the new folder.
5. The launcher reuses `%LOCALAPPDATA%\NexusCRM\data` and creates a pre-upgrade SQLite backup. **Do not copy or overwrite this shared folder.**
6. Sign in with the same administrator account. Check Dashboard, Customers, Jobs, Invoices, and Hybrid Status.
7. If anything fails, stop 2.0 and restart your untouched 1.6 folder. The 2.0 database migration is additive.

The ZIP does not contain your live laptop database. To back it up separately, use the CRM Maintenance/Backup page and keep a protected copy outside your laptop.
