
# Backup and restore
1. Stop Nexus CRM completely.
2. Copy the entire `data/` directory to an encrypted backup location. This includes `crm.sqlite3`, `.session_key`, and `logos/`.
3. Keep the copy outside the application folder. Never publish it to GitHub.
4. Extract the 1.3 package into a *new* folder, then copy your existing `data/` directory into it.
5. Start the new version. Database schema changes are additive.
6. If testing fails, stop 1.3 and start the unchanged 1.2 folder with its original `data/` directory.
7. To restore a database snapshot, stop the app before replacing `data/crm.sqlite3`.
Do not run two app copies against the same SQLite file.
