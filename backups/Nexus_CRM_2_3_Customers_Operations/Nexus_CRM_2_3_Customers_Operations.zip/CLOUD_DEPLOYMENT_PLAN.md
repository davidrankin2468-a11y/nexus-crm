# Nexus CRM 2.0 hybrid cloud architecture — development roadmap

The packaged Windows application is **local-first** and uses its existing SQLite database and account.
There is **no cloud synchronization in this build**. Never run two copies against the same SQLite file.

For production: provision managed PostgreSQL; model tenant_id with composite foreign keys and row-level security; establish secure tenant onboarding, MFA and identity provider; use HTTPS-only APIs and per-device refresh token rotation; implement a durable local outbox with UUID event IDs, idempotent server writes, server-side authorization and optimistic version checks; provide explicit merge/conflict UI; encrypt backups and test restoration; run cross-tenant penetration tests and monitoring; implement signed licenses with billing webhooks; test disconnected edits and reconnect scenarios.

Do not expose the included serve_cloud.py to the public Internet as a commercial service.
