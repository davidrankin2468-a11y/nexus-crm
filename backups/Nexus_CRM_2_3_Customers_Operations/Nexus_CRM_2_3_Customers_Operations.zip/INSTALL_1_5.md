# Install Nexus CRM 1.5 (Windows 11)

1. Close your running CRM window **and stop its Command Prompt server** (Ctrl+C). Do not run two versions simultaneously.
2. Leave your working 1.4.1 folder untouched. Your existing administrator account is in `%LOCALAPPDATA%\NexusCRM\data`.
3. Extract this ZIP to `Documents\Nexus CRM\Nexus CRM 1.5`.
4. Run `start_windows.bat`. It reuses the shared account automatically; **do not create a new administrator**.
5. Before launching the CRM, the launcher saves a consistent SQLite snapshot at `%LOCALAPPDATA%\NexusCRM\backups\pre_upgrade_1_5.sqlite3` and validates integrity. If backup fails, startup stops without running migrations.
6. Log in with your existing username and password. Visit Maintenance to check the shared data location and download the pre-upgrade snapshot.
7. Check Customers, Jobs, Invoices, Reports and Settings. You do **not** need to enter test customer records.

## Rollback
Close 1.5. Reopen your untouched 1.4.1 installation. If data needs reverting, first preserve the current database, then restore the snapshot **while both applications are stopped**. The database backup alone does not contain logo files or `.session_key`; retain the shared `data` directory separately.

## Caution
The ZIP is application code only. It cannot back up the actual live database on your laptop until you run the launcher. Keep any downloaded database backup private; do not upload it to a public repository.
