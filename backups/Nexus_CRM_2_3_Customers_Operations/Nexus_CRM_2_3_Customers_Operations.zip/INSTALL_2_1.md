# Install Nexus CRM 2.1 on Windows 11
1. Stop 2.0 completely, including its command window.
2. Keep the 2.0 folder unchanged as a rollback copy.
3. Extract this ZIP to `Documents\Nexus CRM\Nexus CRM 2.1`.
4. Run `start_windows.bat` from the extracted folder.
5. Log in with your existing administrator account; the shared data directory is reused.
6. Open **Sync Queue**. The queue records future local changes; it does not send data anywhere.
7. If startup fails, stop 2.1 and relaunch 2.0. A pre-upgrade backup is made by the launcher.

Do not move or delete `%LOCALAPPDATA%\NexusCRM`.
