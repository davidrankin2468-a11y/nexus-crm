"""Local change journal only. No outbound network access or cloud sync."""
from flask import session,abort,send_file
from markupsafe import escape
import io,json

def install(app,conn,current,page):
    with conn() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS sync_outbox (
            seq INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id INTEGER NOT NULL,
            entity TEXT NOT NULL,
            entity_id INTEGER NOT NULL,
            operation TEXT NOT NULL CHECK(operation IN ('insert','update','delete')),
            queued_at TEXT NOT NULL DEFAULT (datetime('now'))
        )""")
        # No migration of old records: existing data requires a future initial sync snapshot.
        for entity in ('customers','jobs','estimates','invoices'):
            exists=db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(entity,)).fetchone()
            if not exists:continue
            cols={r['name'] for r in db.execute('PRAGMA table_info('+entity+')')}
            if not {'id','company_id'}<=cols:continue
            for op in ('INSERT','UPDATE','DELETE'):
                alias='OLD' if op=='DELETE' else 'NEW'
                name='sync21_'+entity+'_'+op.lower()
                db.execute(f"""CREATE TRIGGER IF NOT EXISTS {name} AFTER {op} ON {entity}
                    BEGIN INSERT INTO sync_outbox(company_id,entity,entity_id,operation)
                    VALUES({alias}.company_id,'{entity}',{alias}.id,'{op.lower()}'); END""")
    @app.route('/sync-queue')
    def sync_queue():
        cid=current()
        if not cid or not session.get('user_id'):abort(403)
        with conn() as db:
            n=db.execute('SELECT COUNT(*) FROM sync_outbox WHERE company_id=?',(cid,)).fetchone()[0]
            rows=db.execute('SELECT entity,operation,queued_at FROM sync_outbox WHERE company_id=? ORDER BY seq DESC LIMIT 25',(cid,)).fetchall()
        content='<div class="card"><h3>Offline change journal</h3><p>Pending local changes: '+str(n)+'</p><p>Cloud synchronization is NOT active. No records have been uploaded.</p><p>Existing records created before 2.1 are not automatically queued.</p></div>'
        content+='<div class="card">'+''.join('<p>'+str(escape(r['queued_at']))+' — '+str(escape(r['entity']))+' '+str(escape(r['operation']))+'</p>' for r in rows)+'</div>'
        return page('Sync queue',content)
