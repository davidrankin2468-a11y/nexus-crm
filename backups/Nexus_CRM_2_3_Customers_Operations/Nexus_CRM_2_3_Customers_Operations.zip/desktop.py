import threading, webbrowser, time
from waitress import serve
from app import app
if __name__=='__main__':
    threading.Thread(target=lambda: (time.sleep(1.2),webbrowser.open('http://127.0.0.1:8765')),daemon=True).start()
    serve(app,host='127.0.0.1',port=8765,threads=4)
