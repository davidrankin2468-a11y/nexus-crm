import io, os, secrets, sqlite3, shutil
from datetime import datetime,timezone
from pathlib import Path
from flask import request, redirect, abort, send_file, session
from markupsafe import escape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet

def install(app,conn,current,page,hashpw,base):
 with conn() as c:
  columns={r['name'] for r in c.execute('PRAGMA table_info(companies)')}
  for name,typ in [('email','TEXT'),('phone','TEXT'),('address','TEXT'),('accent','TEXT')]:
   if name not in columns:c.execute(f'ALTER TABLE companies ADD COLUMN {name} {typ}')
  columns={r['name'] for r in c.execute('PRAGMA table_info(users)')}
  if 'role' not in columns:c.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'admin'")
 def admin():
  with conn() as c:
   u=c.execute('SELECT role FROM users WHERE id=? AND company_id=?',(session.get('user_id'),current())).fetchone()
  if not u or u['role']!='admin':abort(403)
 def token():return '<input type="hidden" name="csrf" value="{{csrf}}">'
 @app.route('/reports')
 def reports():
  with conn() as c:
   cid=current()
   stats={
    'Customers':c.execute('SELECT COUNT(*) FROM customers WHERE company_id=?',(cid,)).fetchone()[0],
    'Jobs':c.execute('SELECT COUNT(*) FROM jobs WHERE company_id=?',(cid,)).fetchone()[0],
    'Estimates':c.execute('SELECT COUNT(*) FROM estimates WHERE company_id=?',(cid,)).fetchone()[0],
    'Unpaid invoices':c.execute("SELECT COUNT(*) FROM invoices WHERE company_id=? AND status='Unpaid'",(cid,)).fetchone()[0],
   }
   totals=c.execute("SELECT COALESCE(SUM(CASE WHEN status='Paid' THEN amount_cents ELSE 0 END),0),COALESCE(SUM(CASE WHEN status='Unpaid' THEN amount_cents ELSE 0 END),0) FROM invoices WHERE company_id=?",(cid,)).fetchone()
  body='<div class="card"><h3>Company performance</h3>'+''.join(f'<p>{escape(k)}: <strong>{v}</strong></p>' for k,v in stats.items())+f'<p>Paid invoice total: ${totals[0]/100:,.2f}</p><p>Outstanding invoice total: ${totals[1]/100:,.2f}</p><p><small>Based on invoice records, not verified bank receipts.</small></p></div>'
  return page('Reports & Analytics',body)
 @app.route('/company-settings',methods=['GET','POST'])
 def company_settings():
  admin()
  with conn() as c:
   if request.method=='POST':
    name=request.form.get('name','').strip()
    if not name:abort(400)
    accent=request.form.get('accent','#42db80')
    if not (len(accent)==7 and accent[0]=='#' and all(x in '0123456789abcdefABCDEF' for x in accent[1:])):abort(400)
    c.execute('UPDATE companies SET name=?,email=?,phone=?,address=?,accent=? WHERE id=?',(name,request.form.get('email','')[:200],request.form.get('phone','')[:80],request.form.get('address','')[:500],accent,current()))
    return redirect('/company-settings')
   r=c.execute('SELECT * FROM companies WHERE id=?',(current(),)).fetchone()
  def inp(k,label):return f'<label>{label} <input name="{k}" value="{escape(r[k] or "")}"></label>'
  body='<div class="card"><form method="post">'+token()+inp('name','Company name')+inp('email','Email')+inp('phone','Phone')+inp('address','Address')+f'<label>Accent color <input type="color" name="accent" value="{escape(r["accent"] or "#42db80")}"></label><button>Save settings</button></form><p>Logo upload and full theme switching are planned for a later version.</p></div>'
  return page('Company Settings',body)
 @app.route('/users',methods=['GET','POST'])
 def users():
  admin()
  with conn() as c:
   if request.method=='POST':
    username=request.form.get('username','').strip();pw=request.form.get('password','');role=request.form.get('role')
    if not username or len(pw)<12 or role not in ('admin','staff'):abort(400,'Username, role and 12+ character password required')
    salt=secrets.token_hex(16)
    try:c.execute('INSERT INTO users(company_id,username,salt,password_hash,role) VALUES(?,?,?,?,?)',(current(),username,salt,hashpw(pw,salt),role))
    except sqlite3.IntegrityError:abort(409,'Username already exists')
    return redirect('/users')
   rows=c.execute('SELECT username,role FROM users WHERE company_id=? ORDER BY username',(current(),)).fetchall()
  body='<div class="card"><h3>Create login</h3><form method="post">'+token()+'<input name="username" placeholder="Username" required><input name="password" type="password" minlength="12" placeholder="Password (12+ characters)" required><select name="role"><option value="staff">Staff</option><option value="admin">Admin</option></select><button>Add user</button></form></div><div class="card"><table><tr><th>Username</th><th>Role</th></tr>'+''.join(f'<tr><td>{escape(r["username"])}</td><td>{escape(r["role"])}</td></tr>' for r in rows)+'</table></div>'
  return page('User Management',body)
 @app.route('/documents/<kind>/<int:item_id>.pdf')
 def document(kind,item_id):
  if kind not in ('estimates','invoices'):abort(404)
  table='estimates' if kind=='estimates' else 'invoices'
  with conn() as c:
   r=c.execute(f'SELECT t.*,cust.name customer_name,cust.email customer_email,co.name company_name,co.email company_email,co.phone company_phone,co.address company_address FROM {table} t JOIN customers cust ON cust.id=t.customer_id AND cust.company_id=t.company_id JOIN companies co ON co.id=t.company_id WHERE t.id=? AND t.company_id=?',(item_id,current())).fetchone()
  if not r:abort(404)
  stream=io.BytesIO();doc=SimpleDocTemplate(stream,pagesize=(612,792),title=f'{kind.title()} {item_id}')
  styles=getSampleStyleSheet()
  safe=lambda s:escape(str(s or ''))
  story=[Paragraph(safe(r['company_name']),styles['Title']),Paragraph(safe(r['company_address']),styles['Normal']),Paragraph(safe(r['company_email'])+' '+safe(r['company_phone']),styles['Normal']),Spacer(1,20),Paragraph(f'{kind[:-1].title()} #{item_id}',styles['Heading1']),Paragraph('Customer: '+safe(r['customer_name']),styles['Normal']),Paragraph('Customer email: '+safe(r['customer_email']),styles['Normal']),Spacer(1,16)]
  description=r['title'] if kind=='estimates' else r['description']
  tableobj=Table([['Description','Amount'],[Paragraph(safe(description),styles['Normal']),f'${r["amount_cents"]/100:,.2f}']],colWidths=[360,140]);tableobj.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.5,colors.grey),('BACKGROUND',(0,0),(-1,0),colors.lightgrey),('VALIGN',(0,0),(-1,-1),'TOP'),('PADDING',(0,0),(-1,-1),10)]));story.append(tableobj)
  story.append(Spacer(1,15));story.append(Paragraph('Status: '+safe(r['status']),styles['Normal']))
  if kind=='invoices':story.append(Paragraph('Due: '+safe(r['due_date']),styles['Normal']))
  doc.build(story);stream.seek(0)
  return send_file(stream,mimetype='application/pdf',as_attachment=True,download_name=f'nexus_{kind}_{item_id}.pdf')
 @app.route('/restore',methods=['GET','POST'])
 def restore():
  admin()
  if request.method=='POST':
   if request.form.get('confirm')!='RESTORE':abort(400,'Type RESTORE to confirm')
   uploaded=request.files.get('backup')
   if not uploaded or not uploaded.filename.endswith('.sqlite3'):abort(400,'SQLite backup required')
   data=uploaded.read(50*1024*1024+1)
   if len(data)>50*1024*1024 or not data.startswith(b'SQLite format 3\x00'):abort(400,'Invalid or oversized backup')
   db=base/'data'/'crm.sqlite3';temp=base/'data'/('restore_'+secrets.token_hex(8)+'.sqlite3')
   try:
    temp.write_bytes(data)
    with sqlite3.connect(temp) as c:
     if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':abort(400,'Corrupt backup')
     names={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
     if not {'companies','users','customers','jobs','estimates','invoices','appointments','employees'}.issubset(names):abort(400,'Not a compatible Nexus CRM backup')
    # Require explicit offline restore: live SQLite replacement is unsafe while other requests run.
    abort(409,'Backup validated. To restore safely: stop CRM, copy current data/crm.sqlite3 to a safe location, then replace it with the validated backup file. See RESTORE.md. No data was changed.')
   finally:
    temp.unlink(missing_ok=True)
  return page('Restore backup','<div class="card"><p>For safety, the CRM validates uploaded backups but does not replace a live database. See RESTORE.md for offline restore steps.</p><form method="post" enctype="multipart/form-data">'+token()+'<input type="file" name="backup" accept=".sqlite3" required><input name="confirm" placeholder="Type RESTORE" required><button>Validate backup</button></form></div>')
