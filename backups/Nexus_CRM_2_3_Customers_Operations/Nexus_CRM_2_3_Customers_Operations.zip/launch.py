"""Safe one-time import and persistent data directory for Windows CRM upgrades."""
import os,sys,sqlite3,shutil,subprocess
from pathlib import Path
from datetime import datetime

def has_users(db):
    if not db.is_file():return False
    try:
        con=sqlite3.connect(f'file:{db.as_posix()}?mode=ro',uri=True)
        try:
            ok=con.execute("SELECT COUNT(*) FROM users").fetchone()[0]>0
            integrity=con.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
            return ok and integrity
        finally:con.close()
    except sqlite3.Error:return False

def main():
    base=Path(__file__).resolve().parent
    shared=Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/'NexusCRM'/'data'
    target=shared/'crm.sqlite3'
    if not has_users(target):
        if target.exists():
            print('An existing shared database was found but could not be validated. No changes made.')
            input('Press Enter to exit...');return 2
        # Discover only existing sibling versions and current folder; never select silently.
        candidates=[p for p in [base,*base.parent.glob('Nexus CRM*'),*base.parent.glob('Nexus_CRM*')] if (p/'data'/'crm.sqlite3').exists() and has_users(p/'data'/'crm.sqlite3')]
        candidates=list(dict.fromkeys(p.resolve() for p in candidates))
        print('ONE-TIME ACCOUNT TRANSFER')
        print('Choose the CRM folder whose administrator account you want to keep:')
        for i,p in enumerate(candidates,1):print(f'  {i}. {p}')
        print('  M. Enter another CRM folder path')
        print('  Q. Cancel without making changes')
        choice=input('Selection: ').strip()
        if choice.lower()=='q' or not choice:return 1
        if choice.lower()=='m':
            source=Path(input('Full path to old CRM folder: ').strip().strip('"'))/'data'
        else:
            try:source=candidates[int(choice)-1]/'data'
            except (ValueError,IndexError):print('Invalid selection');return 1
        if not has_users(source/'crm.sqlite3'):
            print('Selected folder does not contain a valid CRM administrator database. No changes made.');return 2
        shared.parent.mkdir(parents=True,exist_ok=True)
        temp=shared.parent/'data_import_pending'
        if temp.exists():
            print('Incomplete earlier import found. Please inspect:',temp);return 2
        try:
            shutil.copytree(source,temp)
            if not has_users(temp/'crm.sqlite3'):raise RuntimeError('Copied database failed validation')
            if shared.exists() and any(shared.iterdir()):raise RuntimeError('Destination already contains files; manual review required')
            if shared.exists():shared.rmdir()
            temp.rename(shared)
        except Exception as exc:
            print('Transfer stopped:',exc,'Original folder was not changed.');return 2
        print('Account and database copied into persistent Windows application data.')
    # Consistent pre-upgrade SQLite backup, before importing app.py and migrations.
    backup_dir=shared.parent/'backups'
    backup_dir.mkdir(parents=True,exist_ok=True)
    snapshot=backup_dir/'pre_upgrade_2_3.sqlite3'
    if not snapshot.exists():
        # Keep each attempt in its own temporary file; never overwrite an existing backup.
        import uuid
        pending=backup_dir/('pre_upgrade_2_3_'+uuid.uuid4().hex+'.pending.sqlite3')
        original=None
        copy=None
        try:
            original=sqlite3.connect(str(target),timeout=15)
            copy=sqlite3.connect(str(pending),timeout=15)
            original.backup(copy)
            if copy.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                raise RuntimeError('Backup integrity check failed')
            # On Windows, sqlite connections must be CLOSED before os.replace.
            copy.close();copy=None
            original.close();original=None
            pending.replace(snapshot)
            print('Pre-upgrade database backup saved:',snapshot)
        except Exception as exc:
            print('Upgrade stopped: could not back up database:',exc)
            print('Your existing CRM database has not been replaced.')
            return 2
        finally:
            if copy is not None:copy.close()
            if original is not None:original.close()
            try:pending.unlink(missing_ok=True)
            except PermissionError:
                print('Temporary backup file remains in:',backup_dir)
    os.environ['NEXUS_CRM_DATA_DIR']=str(shared)
    return subprocess.call([sys.executable,str(base/'desktop.py')],cwd=str(base))
if __name__=='__main__':sys.exit(main())
