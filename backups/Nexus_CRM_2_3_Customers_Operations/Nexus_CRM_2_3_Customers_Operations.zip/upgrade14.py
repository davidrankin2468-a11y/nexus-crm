
"""Incremental 1.4 hardening. Does not claim production-ready tenant isolation."""
import time, threading, json, secrets
from flask import request, session, abort, redirect
from markupsafe import escape

def install(app, conn, current, page, base):
    lock=threading.Lock()
    failures={}
    def prune(now):
        for k,v in list(failures.items()):
            if now-v[1]>900:failures.pop(k,None)
    @app.before_request
    def security_guard():
        if request.endpoint=='login' and request.method=='POST':
            # Local, process-scoped protection; cloud needs shared Redis/proxy controls.
            key=(request.remote_addr or 'unknown',request.form.get('username','')[:100])
            now=time.monotonic()
            with lock:
                prune(now)
                count,when=failures.get(key,(0,now))
                if count>=5:abort(429,'Too many attempts. Try again in 15 minutes.')
                failures[key]=(count+1,now)
        if request.method=='POST' and request.endpoint not in ('login','setup','logout','static'):
            if current() and session.get('user_id'):
                with conn() as c:
                    row=c.execute('SELECT role FROM users WHERE id=? AND company_id=?',
                                  (session['user_id'],current())).fetchone()
                if not row:abort(403)
                # Staff can maintain routine records; administrative settings stay restricted
                if request.endpoint in ('users','company_settings','branding','restore','security'):
                    if row['role']!='admin':abort(403)
    @app.after_request
    def security_headers(response):
        response.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
        return response
    @app.route('/security')
    def security():
        with conn() as c:
            role=c.execute('SELECT role FROM users WHERE id=? AND company_id=?',
                           (session.get('user_id'),current())).fetchone()
            if not role or role['role']!='admin':abort(403)
            users=c.execute('SELECT username,role FROM users WHERE company_id=? ORDER BY username',
                            (current(),)).fetchall()
            events=c.execute('SELECT action,created_at FROM audit_events WHERE company_id=? ORDER BY id DESC LIMIT 20',
                             (current(),)).fetchall()
        html='<div class="card"><h3>Accounts</h3>'+''.join(
            '<p>'+str(escape(u['username']))+' — '+str(escape(u['role']))+'</p>' for u in users)
        html+='</div><div class="card"><h3>Recent changes</h3>'+''.join(
            '<p>'+str(escape(e['created_at']))+' — '+str(escape(e['action']))+'</p>' for e in events)
        html+='</div><div class="card"><p>Cloud deployment remains staging-only. Do not expose to the public Internet.</p></div>'
        return page('Security',html)
