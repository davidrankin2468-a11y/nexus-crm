"""Nexus CRM 1.6: explicit staff restrictions and tenant-scoped permissions view."""
from flask import request, session, abort
from markupsafe import escape

ADMIN_ONLY={'users','company_settings','branding','restore','security','audit',
            'maintenance','pre_upgrade_backup','permissions','backup'}

def install(app,conn,current,page,data):
    @app.before_request
    def require_role_for_admin_routes():
        endpoint=request.endpoint
        if endpoint not in ADMIN_ONLY:return
        if not current() or not session.get('user_id'):abort(403)
        with conn() as c:
            user=c.execute('SELECT role FROM users WHERE id=? AND company_id=?',
                           (session['user_id'],current())).fetchone()
        if not user or user['role']!='admin':abort(403)

    @app.route('/permissions')
    def permissions():
        with conn() as c:
            users=c.execute('SELECT username,role FROM users WHERE company_id=? ORDER BY username',
                            (current(),)).fetchall()
        html='<div class="card"><h3>Company accounts</h3>'
        html+=''.join('<p>'+str(escape(u['username']))+' — '+str(escape(u['role']))+'</p>' for u in users)
        html+='</div><div class="card"><h3>Current access policy</h3><p>Admins: settings, users, backups, reports and records. Staff: routine records and reports. This is an interim two-role policy, not full role-based access control.</p></div>'
        return page('Permissions',html)
