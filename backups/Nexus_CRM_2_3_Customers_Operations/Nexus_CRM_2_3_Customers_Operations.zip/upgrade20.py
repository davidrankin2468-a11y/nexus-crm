"""Local-first status and migration-readiness checks; cloud sync is NOT enabled."""
import sqlite3, os, json
from flask import session, abort, jsonify
from markupsafe import escape

def install(app,conn,current,page,data):
    with conn() as c:
        c.execute('CREATE TABLE IF NOT EXISTS schema_migrations(version TEXT PRIMARY KEY, applied_at TEXT NOT NULL)')
        c.execute("INSERT OR IGNORE INTO schema_migrations VALUES('2.0-dev',datetime('now'))")
    @app.route('/hybrid')
    def hybrid_status():
        with conn() as c:
            r=c.execute('SELECT role FROM users WHERE id=? AND company_id=?',(session.get('user_id'),current())).fetchone()
            if not r:abort(403)
            counts={table:c.execute('SELECT COUNT(*) FROM '+table+' WHERE company_id=?',(current(),)).fetchone()[0] for table in ('customers','jobs')}
            integrity=c.execute('PRAGMA quick_check').fetchone()[0]
        return page('Hybrid readiness','<div class="card"><h3>Offline mode: available</h3><p>Local data is available without internet. Online synchronization is NOT configured or active.</p><p>Database check: '+str(escape(integrity))+'</p><p>Customers: '+str(counts['customers'])+'; Jobs: '+str(counts['jobs'])+'</p><p>Cloud deployment requires a separate hosted service, authentication, tenant isolation tests, and a conflict-safe sync engine.</p></div>')
    @app.route('/api/local-health')
    def local_health():
        if not current() or not session.get('user_id'):abort(403)
        return jsonify({'status':'ok','version':'2.0-dev','mode':'local','sync':'disabled'})
