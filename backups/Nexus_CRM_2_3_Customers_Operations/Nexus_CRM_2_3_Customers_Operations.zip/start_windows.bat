@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt || (pause & exit /b 1)
py launch.py
pause
