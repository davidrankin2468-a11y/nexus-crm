from datetime import datetime,timezone
from decimal import Decimal,InvalidOperation
from flask import request,redirect,abort
from markupsafe import escape

def install(app,conn,current,page):
 with conn() as c:
  c.executescript('''CREATE TABLE IF NOT EXISTS estimates(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,customer_id INTEGER NOT NULL,title TEXT NOT NULL,amount_cents INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'Draft',created_at TEXT NOT NULL);CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,customer_id INTEGER NOT NULL,description TEXT NOT NULL,amount_cents INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'Unpaid',due_date TEXT,created_at TEXT NOT NULL);CREATE TABLE IF NOT EXISTS appointments(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,customer_id INTEGER NOT NULL,title TEXT NOT NULL,starts_at TEXT NOT NULL,notes TEXT);CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,name TEXT NOT NULL,role TEXT NOT NULL,phone TEXT,email TEXT);''')
 def money(raw):
  try:
   d=Decimal(str(raw));c=int(d*100)
   if not d.is_finite() or d<0 or d.as_tuple().exponent < -2 or c>10**12:raise ValueError()
   return c
  except (InvalidOperation,ValueError,TypeError):abort(400,'Enter a valid nonnegative amount with up to two decimals')
 def customer_options(c):
  rows=c.execute('SELECT id,name FROM customers WHERE company_id=? ORDER BY name',(current(),)).fetchall()
  return ''.join(f'<option value="{r["id"]}">{escape(r["name"])}</option>' for r in rows)
 def valid_customer(c,customer_id):
  if not c.execute('SELECT 1 FROM customers WHERE id=? AND company_id=?',(customer_id,current())).fetchone():abort(400,'Invalid customer')
 def token():return '<input type="hidden" name="csrf" value="{{csrf}}">'
 @app.route('/estimates',methods=['GET','POST'])
 def estimates():
  with conn() as c:
   if request.method=='POST':
    cid=request.form.get('customer_id');valid_customer(c,cid)
    title=request.form.get('title','').strip()
    if not title:abort(400)
    c.execute('INSERT INTO estimates(company_id,customer_id,title,amount_cents,created_at) VALUES(?,?,?,?,?)',(current(),cid,title,money(request.form.get('amount')),datetime.now(timezone.utc).isoformat()))
    return redirect('/estimates')
   opts=customer_options(c)
   rows=c.execute('SELECT e.*,c.name FROM estimates e JOIN customers c ON c.id=e.customer_id AND c.company_id=e.company_id WHERE e.company_id=? ORDER BY e.id DESC',(current(),)).fetchall()
  body='<div class="card"><h3>New estimate</h3><form method="post">'+token()+f'<select name="customer_id" required>{opts}</select><input name="title" placeholder="Work description" required><input name="amount" type="number" min="0" step="0.01" placeholder="Amount" required><button>Save draft</button></form></div><div class="card"><table><tr><th>Customer</th><th>Work</th><th>Amount</th><th>Status</th><th>PDF</th></tr>'
  for r in rows:body+=f'<tr><td>{escape(r["name"])}</td><td>{escape(r["title"])}</td><td>${r["amount_cents"]/100:,.2f}</td><td>{escape(r["status"])}</td><td><a href="/documents/estimates/{r["id"]}.pdf">Download PDF</a></td></tr>'
  return page('Estimates',body+'</table></div>')
 @app.route('/invoices',methods=['GET','POST'])
 def invoices():
  with conn() as c:
   if request.method=='POST':
    if request.form.get('action')=='mark_paid':
     c.execute("UPDATE invoices SET status='Paid' WHERE id=? AND company_id=?",(request.form.get('invoice_id'),current()))
    else:
     cid=request.form.get('customer_id');valid_customer(c,cid)
     desc=request.form.get('description','').strip()
     if not desc:abort(400)
     due=request.form.get('due_date') or None
     if due:
      try:datetime.strptime(due,'%Y-%m-%d')
      except ValueError:abort(400)
     c.execute('INSERT INTO invoices(company_id,customer_id,description,amount_cents,due_date,created_at) VALUES(?,?,?,?,?,?)',(current(),cid,desc,money(request.form.get('amount')),due,datetime.now(timezone.utc).isoformat()))
    return redirect('/invoices')
   opts=customer_options(c)
   rows=c.execute('SELECT i.*,c.name FROM invoices i JOIN customers c ON c.id=i.customer_id AND c.company_id=i.company_id WHERE i.company_id=? ORDER BY i.id DESC',(current(),)).fetchall()
  body='<div class="card"><h3>New invoice</h3><form method="post">'+token()+f'<select name="customer_id" required>{opts}</select><input name="description" placeholder="Description" required><input name="amount" type="number" min="0" step="0.01" required placeholder="Amount"><input name="due_date" type="date"><button>Create invoice</button></form></div><div class="card"><table><tr><th>Customer</th><th>Description</th><th>Amount</th><th>Due</th><th>Status</th><th>Action</th><th>PDF</th></tr>'
  for r in rows:
   action='' if r['status']=='Paid' else f'<form method="post">{token()}<input type="hidden" name="action" value="mark_paid"><input type="hidden" name="invoice_id" value="{r["id"]}"><button>Mark paid</button></form>'
   body+=f'<tr><td>{escape(r["name"])}</td><td>{escape(r["description"])}</td><td>${r["amount_cents"]/100:,.2f}</td><td>{escape(r["due_date"] or "")}</td><td>{escape(r["status"])}</td><td>{action}</td><td><a href="/documents/invoices/{r["id"]}.pdf">Download PDF</a></td></tr>'
  return page('Invoices',body+'</table></div>')
 @app.route('/schedule',methods=['GET','POST'])
 def schedule():
  with conn() as c:
   if request.method=='POST':
    cid=request.form.get('customer_id');valid_customer(c,cid)
    title=request.form.get('title','').strip();start=request.form.get('starts_at','')
    try:datetime.fromisoformat(start)
    except ValueError:abort(400)
    if not title:abort(400)
    c.execute('INSERT INTO appointments(company_id,customer_id,title,starts_at,notes) VALUES(?,?,?,?,?)',(current(),cid,title,start,request.form.get('notes','')))
    return redirect('/schedule')
   opts=customer_options(c)
   rows=c.execute('SELECT a.*,c.name FROM appointments a JOIN customers c ON c.id=a.customer_id AND c.company_id=a.company_id WHERE a.company_id=? ORDER BY starts_at',(current(),)).fetchall()
  body='<div class="card"><h3>Schedule appointment</h3><form method="post">'+token()+f'<select name="customer_id" required>{opts}</select><input name="title" placeholder="Appointment" required><input type="datetime-local" name="starts_at" required><input name="notes" placeholder="Notes"><button>Schedule</button></form></div><div class="card"><table><tr><th>When</th><th>Customer</th><th>Appointment</th><th>Notes</th></tr>'
  for r in rows:body+=f'<tr><td>{escape(r["starts_at"])}</td><td>{escape(r["name"])}</td><td>{escape(r["title"])}</td><td>{escape(r["notes"] or "")}</td></tr>'
  return page('Schedule',body+'</table></div>')
 @app.route('/employees',methods=['GET','POST'])
 def employees():
  with conn() as c:
   if request.method=='POST':
    name=request.form.get('name','').strip();role=request.form.get('role','').strip()
    if not name or not role:abort(400)
    c.execute('INSERT INTO employees(company_id,name,role,phone,email) VALUES(?,?,?,?,?)',(current(),name,role,request.form.get('phone',''),request.form.get('email','')))
    return redirect('/employees')
   rows=c.execute('SELECT * FROM employees WHERE company_id=? ORDER BY name',(current(),)).fetchall()
  body='<div class="card"><h3>Add employee record</h3><form method="post">'+token()+'<input name="name" placeholder="Employee name" required><input name="role" placeholder="Role" required><input name="phone" placeholder="Phone"><input name="email" placeholder="Email"><button>Add employee</button></form></div><div class="card"><table><tr><th>Name</th><th>Role</th><th>Phone</th><th>Email</th></tr>'
  for r in rows:body+='<tr>'+''.join(f'<td>{escape(r[k] or "")}</td>' for k in ('name','role','phone','email'))+'</tr>'
  return page('Employees',body+'</table></div>')
