import os, sqlite3, secrets, hashlib, hmac, json, shutil
from decimal import Decimal, InvalidOperation
from datetime import datetime, timezone
from pathlib import Path
from flask import Flask, request, session, redirect, render_template_string, flash, send_file, abort
from markupsafe import escape as markup_escape

def esc(value):
 return str(markup_escape(value))

BASE=Path(__file__).resolve().parent
DATA=Path(os.environ.get('NEXUS_CRM_DATA_DIR',str(BASE/'data'))); DATA.mkdir(parents=True,exist_ok=True)
DB=DATA/'crm.sqlite3'
app=Flask(__name__)
SECRET_FILE=DATA/'.session_key'
if not SECRET_FILE.exists():
 SECRET_FILE.write_text(secrets.token_hex(32)); os.chmod(SECRET_FILE,0o600)
app.secret_key=os.environ.get('NEXUS_SECRET_KEY') or SECRET_FILE.read_text().strip()
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',
                  SESSION_COOKIE_SECURE=os.environ.get('NEXUS_HTTPS','0')=='1',
                  PERMANENT_SESSION_LIFETIME=__import__('datetime').timedelta(hours=8),
                  MAX_CONTENT_LENGTH=10*1024*1024)


def conn():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');return c

def init():
 with conn() as c:
  c.executescript('''CREATE TABLE IF NOT EXISTS companies(id INTEGER PRIMARY KEY,name TEXT NOT NULL);CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL REFERENCES companies(id),username TEXT UNIQUE NOT NULL,salt TEXT NOT NULL,password_hash TEXT NOT NULL);CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL REFERENCES companies(id),name TEXT NOT NULL,email TEXT,phone TEXT,notes TEXT,created_at TEXT NOT NULL);CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL REFERENCES companies(id),customer_id INTEGER NOT NULL REFERENCES customers(id),title TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'Planned',amount REAL NOT NULL DEFAULT 0,created_at TEXT NOT NULL);''')
init()
def hashpw(p,s):return hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(s),310000).hex()
def current():return session.get('company_id')
def csrf():
 if 'csrf' not in session:session['csrf']=secrets.token_hex(24)
 return session['csrf']
@app.before_request
def guard():
 if request.method=='POST' and request.form.get('csrf')!=csrf():abort(400)
 if request.endpoint not in ('login','setup','static') and current() and not session.get('user_id'):abort(403)
 if request.endpoint not in ('login','setup','static') and not current():return redirect('/login')
 if current() and request.endpoint not in ('login','setup','logout','static'):
  with conn() as c:
   if not c.execute('SELECT 1 FROM users WHERE id=? AND company_id=?',(session.get('user_id'),current())).fetchone():
    session.clear();return redirect('/login')
STYLE='''<meta name="viewport" content="width=device-width,initial-scale=1"><style>
:root{color-scheme:dark;--bg:#0b1523;--panel:#17283b;--line:#29465a;--green:#42db80}
*{box-sizing:border-box}body{font:16px system-ui;background:var(--bg);color:#eaf5ef;margin:0}a{color:#6dff9d}
.shell{display:grid;grid-template-columns:224px minmax(0,1fr);min-height:100vh}
.sidebar{background:#101f31;border-right:1px solid var(--line);padding:20px 14px}
.brand{font-size:18px;font-weight:750;display:block;margin-bottom:28px;color:#eaf5ef;text-decoration:none}
.sidebar nav a{display:block;color:#cfe4dc;text-decoration:none;padding:11px 13px;border-radius:8px;margin:5px 0}
.sidebar nav a:hover,.sidebar nav a.active{background:#254437;color:#8affb0}
.sidebar nav .signout{margin-top:28px;border-top:1px solid var(--line);padding-top:18px}
.content{min-width:0;padding:28px clamp(14px,4vw,50px)}main{max-width:1100px;margin:auto}
.card{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:22px;margin:14px 0}
input,select,textarea{padding:11px;margin:6px;background:var(--bg);color:white;border:1px solid #466177;border-radius:6px;max-width:100%}
button{padding:11px 18px;background:var(--green);color:#07151b;border:0;border-radius:6px;font-weight:bold;cursor:pointer}
table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:10px;border-bottom:1px solid var(--line)}
textarea{min-height:78px;vertical-align:top}.metrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(165px,1fr));gap:12px}.metric{background:#17283b;border:1px solid #29465a;border-radius:12px;padding:18px}.metric strong{display:block;color:#95fbb6;font-size:24px;margin-top:10px}.toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:8px}.toolbar input{flex:1;min-width:160px}.toolbar select{max-width:220px}.button-link{display:inline-block;background:#254437;padding:8px 12px;border-radius:7px;text-decoration:none}.muted{color:#9fb7c4;font-size:14px}.small-button{padding:8px 10px;font-size:12px}.subnav{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0 22px}.subnav a{padding:9px 12px;border:1px solid var(--line);border-radius:8px;text-decoration:none}.subnav a.active{background:#244434;color:#a0ffb8}
@media(max-width:760px){.shell{display:block}.sidebar{padding:12px}.brand{margin-bottom:10px}.sidebar nav{display:flex;overflow-x:auto;gap:5px}.sidebar nav a{white-space:nowrap}.sidebar nav .signout{margin:5px 0;border:0;padding:11px}.content{padding:16px}table{display:block;overflow-x:auto;white-space:nowrap}}
</style>'''
SECTIONS={
 'Dashboard':[('/', 'Overview')],
 'Customers':[('/customers','Customers')],
 'Operations':[('/jobs','Jobs'),('/schedule','Schedule'),('/employees','Employees')],
 'Finance':[('/estimates','Estimates'),('/invoices','Invoices'),('/reports','Reports')],
 'Management':[('/company-settings','Settings'),('/users','Users'),('/branding','Branding'),('/security','Security'),('/permissions','Permissions'),('/maintenance','Maintenance'),('/hybrid','Hybrid Status'),('/sync-queue','Sync Queue'),('/backup','Backup'),('/restore','Restore'),('/audit','Audit')]
}
def page(title,body):
 path=request.path
 section=next((k for k,links in SECTIONS.items() if any(path==url for url,_ in links)), 'Dashboard')
 if path.startswith('/customers/'):section='Customers'
 elif path.startswith('/jobs/'):section='Operations'
 mainlinks=[(k,links[0][0],k==section) for k,links in SECTIONS.items()]
 sublinks=SECTIONS.get(section,[])
 nav=''.join('<a class="'+('active' if active else '')+'" href="'+url+'">'+esc(name)+'</a>' for name,url,active in mainlinks)
 sub=''.join('<a class="'+('active' if path==url else '')+'" href="'+url+'">'+esc(label)+'</a>' for url,label in sublinks)
 if current():
  shell='<div class="shell"><aside class="sidebar"><a class="brand" href="/">◈ Nexus CRM 2.3</a><nav>'+nav+'<a class="signout" href="/logout">Sign out</a></nav></aside><div class="content"><main><div class="subnav">'+sub+'</div><h1>'+esc(title)+'</h1>'+body+'</main></div></div>'
 else:shell='<div class="content"><main><h1>'+esc(title)+'</h1>'+body+'</main></div>'
 return render_template_string('{{ html|safe }}',html=STYLE+shell.replace('{{csrf}}',esc(csrf())))
@app.route('/setup',methods=['GET','POST'])
def setup():
 with conn() as c:exists=c.execute('SELECT COUNT(*) FROM users').fetchone()[0]
 if exists:return redirect('/login')
 if request.method=='POST':
  name=request.form['company'].strip();user=request.form['username'].strip();pw=request.form['password']
  if not name or not user or len(pw)<12:return 'Provide company, username and password of at least 12 characters',400
  salt=secrets.token_hex(16)
  with conn() as c:
   cid=c.execute('INSERT INTO companies(name) VALUES(?)',(name,)).lastrowid
   c.execute('INSERT INTO users(company_id,username,salt,password_hash) VALUES(?,?,?,?)',(cid,user,salt,hashpw(pw,salt)))
  return redirect('/login')
 return page('First-time setup','''<div class="card"><form method="post"><input type="hidden" name="csrf" value="{{csrf}}"><input name="company" placeholder="Company name" required><input name="username" placeholder="Admin username" required><input name="password" type="password" minlength="12" placeholder="Password (12+ characters)" required><button>Create account</button></form></div>''')
@app.route('/login',methods=['GET','POST'])
def login():
 with conn() as c:
  if not c.execute('SELECT 1 FROM users').fetchone():return redirect('/setup')
 if request.method=='POST':
  with conn() as c:u=c.execute('SELECT * FROM users WHERE username=?',(request.form['username'],)).fetchone()
  if u and hmac.compare_digest(hashpw(request.form['password'],u['salt']),u['password_hash']):
   session.clear();session['company_id']=u['company_id'];session['user_id']=u['id'];session.permanent=True;return redirect('/')
  return 'Invalid login',401
 return page('Sign in','''<div class="card"><form method="post"><input type="hidden" name="csrf" value="{{csrf}}"><input name="username" placeholder="Username" required><input type="password" name="password" placeholder="Password" required><button>Sign in</button></form></div>''')
@app.route('/logout')
def logout():session.clear();return redirect('/login')
@app.route('/')
def home():
 with conn() as c:
  cid=current()
  n=c.execute('SELECT COUNT(*) FROM customers WHERE company_id=?',(cid,)).fetchone()[0]
  active=c.execute("SELECT COUNT(*) FROM jobs WHERE company_id=? AND status NOT IN ('Completed','Cancelled')",(cid,)).fetchone()[0]
  company=c.execute('SELECT name FROM companies WHERE id=?',(cid,)).fetchone()['name']
  total=c.execute("SELECT COALESCE(SUM(CASE WHEN status='Paid' THEN amount_cents ELSE 0 END),0) paid, COALESCE(SUM(CASE WHEN status='Unpaid' THEN amount_cents ELSE 0 END),0) unpaid FROM invoices WHERE company_id=?",(cid,)).fetchone()
  recent=c.execute('''SELECT jobs.title,jobs.status,customers.name FROM jobs
                     JOIN customers ON customers.id=jobs.customer_id AND customers.company_id=jobs.company_id
                     WHERE jobs.company_id=? ORDER BY jobs.id DESC LIMIT 6''',(cid,)).fetchall()
 cards=(('Customers',str(n)),('Open jobs',str(active)),('Paid invoice total',f'${total["paid"]/100:,.2f}'),('Unpaid invoices',f'${total["unpaid"]/100:,.2f}'))
 body='<div class="card"><h2>'+str(esc(company))+'</h2><p class="muted">Financial totals come from CRM invoice records, not bank deposits. Cloud sync is not active.</p></div>'
 body+='<div class="metrics">'+''.join('<div class="metric">'+esc(label)+'<strong>'+esc(value)+'</strong></div>' for label,value in cards)+'</div>'
 body+='<div class="card"><h3>Recent work</h3><table><tr><th>Job</th><th>Customer</th><th>Status</th></tr>'
 body+=''.join('<tr><td>'+esc(r['title'])+'</td><td>'+esc(r['name'])+'</td><td>'+esc(r['status'])+'</td></tr>' for r in recent)
 body+='</table><p><a class="button-link" href="/jobs">Manage jobs</a> <a class="button-link" href="/customers">Manage customers</a></p></div>'
 return page('Dashboard',body)

@app.route('/customers',methods=['GET','POST'])
def customers():
 if request.method=='POST':
  name=request.form.get('name','').strip()
  if not name or len(name)>200:abort(400,'Customer name is required (up to 200 characters)')
  email=request.form.get('email','').strip()[:200]
  phone=request.form.get('phone','').strip()[:80]
  notes=request.form.get('notes','').strip()[:2000]
  with conn() as c:
   c.execute('INSERT INTO customers(company_id,name,email,phone,notes,created_at) VALUES(?,?,?,?,?,?)',(current(),name,email,phone,notes,datetime.now(timezone.utc).isoformat()))
  return redirect('/customers')
 query=request.args.get('q','').strip()[:120]
 with conn() as c:
  if query:
   rows=c.execute('''SELECT * FROM customers WHERE company_id=? AND (
      instr(lower(name),lower(?))>0 OR instr(lower(coalesce(email,'')),lower(?))>0
      OR instr(lower(coalesce(phone,'')),lower(?))>0) ORDER BY name''',(current(),query,query,query)).fetchall()
  else:
   rows=c.execute('SELECT * FROM customers WHERE company_id=? ORDER BY name',(current(),)).fetchall()
 body='''<div class="card"><h3>Add customer</h3><form method="post"><input type="hidden" name="csrf" value="{{csrf}}"><input name="name" maxlength="200" placeholder="Customer name" required><input name="email" maxlength="200" type="email" placeholder="Email"><input name="phone" maxlength="80" placeholder="Phone"><input name="notes" maxlength="2000" placeholder="Notes"><button>Add customer</button></form></div>'''
 body+='<div class="card"><h3>Customer directory</h3><form class="toolbar" method="get" action="/customers"><input type="search" name="q" maxlength="120" placeholder="Search name, email or phone" value="'+esc(query)+'"><button>Search</button> <a href="/customers">Clear</a></form>'
 body+='<p class="muted">'+str(len(rows))+' customer(s) found.</p><table><tr><th>Customer</th><th>Email</th><th>Phone</th><th>Actions</th></tr>'
 for r in rows:
  body+=f'<tr><td>{esc(r["name"])}</td><td>{esc(r["email"] or "")}</td><td>{esc(r["phone"] or "")}</td><td><a class="button-link" href="/customers/{r["id"]}/edit">View / edit</a></td></tr>'
 return page('Customers',body+'</table></div>')

@app.route('/customers/<int:customer_id>/edit',methods=['GET','POST'])
def edit_customer(customer_id):
 with conn() as c:
  customer=c.execute('SELECT * FROM customers WHERE id=? AND company_id=?',(customer_id,current())).fetchone()
  if customer is None:abort(404)
  if request.method=='POST':
   name=request.form.get('name','').strip()
   if not name or len(name)>200:abort(400,'Name is required (up to 200 characters)')
   email=request.form.get('email','').strip()[:200]
   phone=request.form.get('phone','').strip()[:80]
   notes=request.form.get('notes','').strip()[:2000]
   c.execute('UPDATE customers SET name=?,email=?,phone=?,notes=? WHERE id=? AND company_id=?',(name,email,phone,notes,customer_id,current()))
   return redirect('/customers')
  jobs=c.execute('SELECT title,status FROM jobs WHERE company_id=? AND customer_id=? ORDER BY id DESC LIMIT 20',(current(),customer_id)).fetchall()
 def inp(field,label):return '<label>'+label+' <input name="'+field+'" maxlength="'+('200' if field in ('name','email') else '80')+'" value="'+esc(customer[field] or '')+'" '+('required' if field=='name' else '')+'></label>'
 body='<div class="card"><h3>Customer profile</h3><form method="post"><input type="hidden" name="csrf" value="{{csrf}}">'
 body+=inp('name','Name')+inp('email','Email')+inp('phone','Phone')
 body+='<p><label>Notes<br><textarea name="notes" maxlength="2000" rows="3">'+esc(customer['notes'] or '')+'</textarea></label></p><button>Save changes</button> <a href="/customers">Cancel</a></form></div>'
 body+='<div class="card"><h3>Related jobs</h3><table><tr><th>Job</th><th>Status</th></tr>'
 body+=''.join('<tr><td>'+esc(j['title'])+'</td><td>'+esc(j['status'])+'</td></tr>' for j in jobs)
 return page('Edit customer',body+'</table></div>')

JOB_STATUSES=('Planned','Scheduled','In Progress','On Hold','Completed','Cancelled')
@app.route('/jobs',methods=['GET','POST'])
def jobs():
 if request.method=='POST':
  cid=request.form.get('customer_id')
  title=request.form.get('title','').strip()
  if not title or len(title)>200:abort(400,'Job title must be 1–200 characters')
  try:
   amount=Decimal(request.form.get('amount') or '0')
   if not amount.is_finite() or amount<0 or amount>Decimal('10000000000') or amount.as_tuple().exponent < -2:raise ValueError()
  except (InvalidOperation,ValueError):abort(400,'Invalid job amount')
  with conn() as c:
   customer=c.execute('SELECT id FROM customers WHERE id=? AND company_id=?',(cid,current())).fetchone()
   if not customer:abort(400,'Invalid customer')
   c.execute('INSERT INTO jobs(company_id,customer_id,title,status,amount,created_at) VALUES(?,?,?,?,?,?)',(current(),customer['id'],title,'Planned',float(amount),datetime.now(timezone.utc).isoformat()))
  return redirect('/jobs')
 status=request.args.get('status','')
 if status not in JOB_STATUSES:status=''
 with conn() as c:
  cs=c.execute('SELECT id,name FROM customers WHERE company_id=? ORDER BY name',(current(),)).fetchall()
  sql='''SELECT jobs.id,jobs.title,jobs.status,jobs.amount,customers.name FROM jobs
         JOIN customers ON jobs.customer_id=customers.id AND jobs.company_id=customers.company_id
         WHERE jobs.company_id=?'''
  args=[current()]
  if status:sql+=' AND jobs.status=?';args.append(status)
  js=c.execute(sql+' ORDER BY jobs.id DESC',args).fetchall()
 opts=''.join(f'<option value="{x["id"]}">{esc(x["name"])}</option>' for x in cs)
 body=f'''<div class="card"><h3>New job</h3><form method="post"><input type="hidden" name="csrf" value="{{{{csrf}}}}"><select name="customer_id" required>{opts}</select><input name="title" maxlength="200" placeholder="Job title" required><input type="number" step="0.01" min="0" name="amount" placeholder="Estimated amount"><button>Add job</button></form></div>'''
 body+='<div class="card"><h3>Jobs and status</h3><form class="toolbar" method="get" action="/jobs"><select name="status"><option value="">All statuses</option>'
 body+=''.join('<option value="'+esc(x)+'"'+(' selected' if x==status else '')+'>'+esc(x)+'</option>' for x in JOB_STATUSES)
 body+='</select><button>Filter</button> <a href="/jobs">Clear</a></form><p class="muted">'+str(len(js))+' job(s) found.</p>'
 body+='<table><tr><th>Job</th><th>Customer</th><th>Status</th><th>Amount</th><th>Update</th></tr>'
 for j in js:
  select=''.join('<option value="'+esc(x)+'"'+(' selected' if x==j['status'] else '')+'>'+esc(x)+'</option>' for x in JOB_STATUSES)
  body+=f'<tr><td>{esc(j["title"])}</td><td>{esc(j["name"])}</td><td>{esc(j["status"])}</td><td>${j["amount"]:,.2f}</td><td><form method="post" action="/jobs/{j["id"]}/status"><input type="hidden" name="csrf" value="{{{{csrf}}}}"><select name="status">{select}</select><button class="small-button">Save</button></form></td></tr>'
 return page('Jobs',body+'</table></div>')

@app.route('/jobs/<int:job_id>/status',methods=['POST'])
def job_status(job_id):
 status=request.form.get('status','')
 if status not in JOB_STATUSES:abort(400,'Invalid job status')
 with conn() as c:
  result=c.execute('UPDATE jobs SET status=? WHERE id=? AND company_id=?',(status,job_id,current()))
  if result.rowcount!=1:abort(404)
 return redirect('/jobs')

@app.route('/backup',methods=['GET','POST'])
def backup():
 if request.method=='POST':
  folder=BASE/'backups';folder.mkdir(exist_ok=True)
  target=folder/('nexus_crm_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')+'.sqlite3')
  with conn() as src, sqlite3.connect(target) as dst:src.backup(dst)
  return send_file(target,as_attachment=True,download_name=target.name)
 return page('Database backup','''<div class="card"><p>Create a consistent SQLite database snapshot and download it to a safe location. Backup files contain customer data and password hashes; protect them.</p><form method="post"><input type="hidden" name="csrf" value="{{csrf}}"><button>Create & download backup</button></form></div>''')
from features import install as install_features
install_features(app,conn,current,page)
from upgrade12 import install as install_upgrade12
install_upgrade12(app,conn,current,page,hashpw,BASE)
from upgrade13 import install as install_upgrade13
install_upgrade13(app,conn,current,page,BASE)
from upgrade14 import install as install_upgrade14
install_upgrade14(app,conn,current,page,BASE)
from upgrade15 import install as install_upgrade15
install_upgrade15(app,conn,current,page,DATA)
from upgrade16 import install as install_upgrade16
install_upgrade16(app,conn,current,page,DATA)
from upgrade20 import install as install_upgrade20
install_upgrade20(app,conn,current,page,DATA)
from upgrade21 import install as install_upgrade21
install_upgrade21(app,conn,current,page)
if __name__=='__main__':
 print('Open http://127.0.0.1:8765')
 app.run(host='127.0.0.1',port=8765,debug=False)
