
"""1.5 local maintenance UI and tenant-scoped administration."""
from pathlib import Path
from flask import request,session,abort,send_file
from markupsafe import escape
import sqlite3

def install(app,conn,current,page,data):
    def require_admin():
        if not current() or not session.get('user_id'):abort(403)
        with conn() as c:
            u=c.execute('SELECT role FROM users WHERE id=? AND company_id=?',
                        (session['user_id'],current())).fetchone()
        if not u or u['role']!='admin':abort(403)
    @app.route('/maintenance')
    def maintenance():
        require_admin()
        with conn() as c:
            company=c.execute('SELECT name FROM companies WHERE id=?',(current(),)).fetchone()
            counts={t:c.execute('SELECT COUNT(*) FROM '+t+' WHERE company_id=?',(current(),)).fetchone()[0]
                    for t in ('customers','jobs','estimates','invoices','employees')}
        backup=data.parent/'backups'/'pre_upgrade_1_5.sqlite3'
        status='Verified pre-upgrade snapshot available' if backup.is_file() else 'No pre-upgrade snapshot found'
        body='<div class="card"><h3>Shared data location</h3><p>'+str(escape(str(data)))+'</p>'
        body+='<p>Company: '+str(escape(company['name']))+'</p>'
        body+=''.join('<p>'+str(escape(k.title()))+': '+str(v)+'</p>' for k,v in counts.items())
        body+='<p>'+str(escape(status))+'</p>'
        if backup.is_file():body+='<p><a href="/maintenance/pre-upgrade-backup">Download pre-upgrade database backup</a></p>'
        body+='</div><div class="card"><p>Keep the previous version folder. Backups contain sensitive records and password hashes; store privately.</p></div>'
        return page('Maintenance & Upgrade',body)
    @app.route('/maintenance/pre-upgrade-backup')
    def pre_upgrade_backup():
        require_admin()
        p=data.parent/'backups'/'pre_upgrade_1_5.sqlite3'
        if not p.is_file():abort(404)
        return send_file(p,as_attachment=True,download_name='nexus_crm_pre_upgrade_1_5.sqlite3')
