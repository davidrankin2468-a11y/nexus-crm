# Safe upgrade checklist — Nexus CRM 2.3

- Preserve the previously installed Nexus CRM 2.2 and the entire `%LOCALAPPDATA%\NexusCRM` folder.
- Exit the running application completely before starting this version.
- Extract the entire 2.3 ZIP to a **new** folder on Windows 11; do not mix it with old version files.
- Run `start_windows.bat`. The launcher reuses the shared data directory and creates a new pre-upgrade backup if `pre_upgrade_2_3.sqlite3` does not already exist.
- Sign in using your existing account. Never create a replacement administrator account if you already have one.
- Try Customers search/edit; create a test job in Operations, then update its status; check the Dashboard invoice totals.
- If an issue occurs, stop 2.3, reopen 2.2, and report the exact error. Do not delete the existing database.
- Vercel is a **separate demo**, not a cloud replica of this local CRM. Never upload your real data, account secrets, SQLite database, or backup ZIP into a public website repository.
