
import re, os, secrets, sqlite3
from flask import request, redirect, abort, session, send_from_directory
from markupsafe import escape

def install(app,conn,current,page,base):
    with conn() as c:
        columns={r['name'] for r in c.execute('PRAGMA table_info(companies)')}
        if 'logo_filename' not in columns:
            c.execute('ALTER TABLE companies ADD COLUMN logo_filename TEXT')
        c.execute("""CREATE TABLE IF NOT EXISTS audit_events(
            id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL, action TEXT NOT NULL, created_at TEXT NOT NULL)""")
    def admin():
        with conn() as c:
            u=c.execute('SELECT role FROM users WHERE id=? AND company_id=?',
                        (session.get('user_id'),current())).fetchone()
        if not u or u['role']!='admin': abort(403)
    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options']='nosniff'
        response.headers['X-Frame-Options']='DENY'
        response.headers['Referrer-Policy']='strict-origin-when-cross-origin'
        response.headers['Content-Security-Policy']="default-src 'self' 'unsafe-inline'; img-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
        if os.environ.get('NEXUS_HTTPS')=='1':
            response.headers['Strict-Transport-Security']='max-age=31536000'
        response.headers['Cache-Control']='no-store'
        return response
    @app.route('/branding',methods=['GET','POST'])
    def branding():
        admin()
        if request.method=='POST':
            color=request.form.get('accent','#42db80')
            if not re.fullmatch(r'#[0-9a-fA-F]{6}',color):abort(400)
            logo=request.files.get('logo')
            filename=None
            if logo and logo.filename:
                data=logo.read(512*1024+1)
                if len(data)>512*1024:abort(413)
                # Only accept PNG with its real file signature, not just extension.
                if not data.startswith(b'\\x89PNG\\r\\n\\x1a\\n'):abort(400,'PNG logo required')
                filename='company_'+str(current())+'.png'
                folder=base/'data'/'logos';folder.mkdir(exist_ok=True)
                (folder/filename).write_bytes(data)
            with conn() as c:
                c.execute('UPDATE companies SET accent=? WHERE id=?',(color,current()))
                if filename:c.execute('UPDATE companies SET logo_filename=? WHERE id=?',(filename,current()))
            return redirect('/branding')
        with conn() as c:
            row=c.execute('SELECT name,accent,logo_filename FROM companies WHERE id=?',(current(),)).fetchone()
        logo='<p><img style="max-width:180px;max-height:100px" src="/company-logo"></p>' if row['logo_filename'] else ''
        return page('Company Branding','<div class="card"><h2>'+str(escape(row['name']))+
            '</h2>'+logo+'<form method="post" enctype="multipart/form-data">'+
            '<input type="hidden" name="csrf" value="{{csrf}}">'+
            '<label>Accent color <input type="color" name="accent" value="'+str(escape(row['accent'] or '#42db80'))+'"></label>'+
            '<label>Logo (PNG, max 512 KB) <input type="file" name="logo" accept="image/png"></label>'+
            '<button>Save branding</button></form><p>Company name and contact details are in Settings.</p></div>')
    @app.route('/company-logo')
    def company_logo():
        with conn() as c:
            r=c.execute('SELECT logo_filename FROM companies WHERE id=?',(current(),)).fetchone()
        if not r or not r['logo_filename']:abort(404)
        return send_from_directory(base/'data'/'logos',r['logo_filename'],mimetype='image/png')
    @app.before_request
    def audit_mutations():
        # Keep only event metadata, not passwords or customer data.
        if request.method=='POST' and current() and session.get('user_id'):
            with conn() as c:
                c.execute("INSERT INTO audit_events(company_id,user_id,action,created_at) VALUES(?,?,?,datetime('now'))",
                          (current(),session['user_id'],request.path[:160]))
    @app.route('/audit')
    def audit():
        admin()
        with conn() as c:
            rows=c.execute('SELECT action,created_at FROM audit_events WHERE company_id=? ORDER BY id DESC LIMIT 100',(current(),)).fetchall()
        return page('Recent activity','<div class="card">'+''.join('<p>'+str(escape(r['created_at']))+' — '+str(escape(r['action']))+'</p>' for r in rows)+'</div>')
