# Nexus CRM 2.1 — Local synchronization foundation
Builds on the working 2.0 local-first application. Adds a company-scoped local change journal (SQLite triggers for INSERT/UPDATE/DELETE on customers, jobs, estimates, and invoices where present) and a read-only Sync Queue screen.

**No cloud connection, PostgreSQL server, conflict resolution, tenant onboarding, or licensing has been implemented in this package.** This is a safe intermediate development release. Existing records need a future initial snapshot process; only subsequent changes are journaled. Do not expose this app to the public internet.

Read INSTALL_2_1.md before launching. All database changes are additive; original 2.0 folder remains your rollback copy.
