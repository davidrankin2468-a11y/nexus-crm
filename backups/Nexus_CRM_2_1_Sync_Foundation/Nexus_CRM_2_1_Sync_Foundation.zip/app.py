import os, sqlite3, secrets, hashlib, hmac, json, shutil
from datetime import datetime, timezone
from pathlib import Path
from flask import Flask, request, session, redirect, render_template_string, flash, send_file, abort

BASE=Path(__file__).resolve().parent
DATA=Path(os.environ.get('NEXUS_CRM_DATA_DIR',str(BASE/'data'))); DATA.mkdir(parents=True,exist_ok=True)
DB=DATA/'crm.sqlite3'
app=Flask(__name__)
SECRET_FILE=DATA/'.session_key'
if not SECRET_FILE.exists():
 SECRET_FILE.write_text(secrets.token_hex(32)); os.chmod(SECRET_FILE,0o600)
app.secret_key=os.environ.get('NEXUS_SECRET_KEY') or SECRET_FILE.read_text().strip()
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',
                  SESSION_COOKIE_SECURE=os.environ.get('NEXUS_HTTPS','0')=='1',
                  PERMANENT_SESSION_LIFETIME=__import__('datetime').timedelta(hours=8),
                  MAX_CONTENT_LENGTH=10*1024*1024)


def conn():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');return c

def init():
 with conn() as c:
  c.executescript('''CREATE TABLE IF NOT EXISTS companies(id INTEGER PRIMARY KEY,name TEXT NOT NULL);CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL REFERENCES companies(id),username TEXT UNIQUE NOT NULL,salt TEXT NOT NULL,password_hash TEXT NOT NULL);CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL REFERENCES companies(id),name TEXT NOT NULL,email TEXT,phone TEXT,notes TEXT,created_at TEXT NOT NULL);CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL REFERENCES companies(id),customer_id INTEGER NOT NULL REFERENCES customers(id),title TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'Planned',amount REAL NOT NULL DEFAULT 0,created_at TEXT NOT NULL);''')
init()
def hashpw(p,s):return hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(s),310000).hex()
def current():return session.get('company_id')
def csrf():
 if 'csrf' not in session:session['csrf']=secrets.token_hex(24)
 return session['csrf']
@app.before_request
def guard():
 if request.method=='POST' and request.form.get('csrf')!=csrf():abort(400)
 if request.endpoint not in ('login','setup','static') and current() and not session.get('user_id'):abort(403)
 if request.endpoint not in ('login','setup','static') and not current():return redirect('/login')
 if current() and request.endpoint not in ('login','setup','logout','static'):
  with conn() as c:
   if not c.execute('SELECT 1 FROM users WHERE id=? AND company_id=?',(session.get('user_id'),current())).fetchone():
    session.clear();return redirect('/login')
STYLE='''<meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font:16px system-ui;background:#0b1523;color:#eaf5ef;margin:0}header{padding:20px;background:#142338;display:flex;justify-content:space-between}a{color:#6dff9d}main{max-width:1050px;margin:35px auto;padding:0 18px}.card{background:#17283b;border:1px solid #29465a;border-radius:12px;padding:22px;margin:14px 0}input,select{padding:11px;margin:6px;background:#0b1523;color:white;border:1px solid #466177;border-radius:6px}button{padding:11px 18px;background:#42db80;color:#07151b;border:0;border-radius:6px;font-weight:bold;cursor:pointer}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:10px;border-bottom:1px solid #29465a}nav a{margin-right:12px;display:inline-block;margin-bottom:8px}@media(max-width:720px){header{display:block;padding:12px}main{margin:14px auto}input,select{max-width:90%;box-sizing:border-box}table{display:block;overflow-x:auto;white-space:nowrap}}</style>'''
def page(title,body):return render_template_string(STYLE+'''<header><b>◈ Nexus CRM 2.1 Hybrid</b><nav>{% if logged %}<a href="/">Dashboard</a><a href="/customers">Customers</a><a href="/jobs">Jobs</a><a href="/estimates">Estimates</a><a href="/invoices">Invoices</a><a href="/schedule">Schedule</a><a href="/employees">Employees</a><a href="/reports">Reports</a><a href="/company-settings">Settings</a><a href="/users">Users</a><a href="/branding">Branding</a><a href="/security">Security</a><a href="/maintenance">Maintenance</a><a href="/permissions">Permissions</a><a href="/hybrid">Hybrid Status</a><a href="/sync-queue">Sync Queue</a><a href="/backup">Backup</a><a href="/restore">Restore</a><a href="/logout">Sign out</a>{% endif %}</nav></header><main><h1>{{title}}</h1>'''+body+'</main>',title=title,logged=bool(current()),csrf=csrf())
@app.route('/setup',methods=['GET','POST'])
def setup():
 with conn() as c:exists=c.execute('SELECT COUNT(*) FROM users').fetchone()[0]
 if exists:return redirect('/login')
 if request.method=='POST':
  name=request.form['company'].strip();user=request.form['username'].strip();pw=request.form['password']
  if not name or not user or len(pw)<12:return 'Provide company, username and password of at least 12 characters',400
  salt=secrets.token_hex(16)
  with conn() as c:
   cid=c.execute('INSERT INTO companies(name) VALUES(?)',(name,)).lastrowid
   c.execute('INSERT INTO users(company_id,username,salt,password_hash) VALUES(?,?,?,?)',(cid,user,salt,hashpw(pw,salt)))
  return redirect('/login')
 return page('First-time setup','''<div class="card"><form method="post"><input type="hidden" name="csrf" value="{{csrf}}"><input name="company" placeholder="Company name" required><input name="username" placeholder="Admin username" required><input name="password" type="password" minlength="12" placeholder="Password (12+ characters)" required><button>Create account</button></form></div>''')
@app.route('/login',methods=['GET','POST'])
def login():
 with conn() as c:
  if not c.execute('SELECT 1 FROM users').fetchone():return redirect('/setup')
 if request.method=='POST':
  with conn() as c:u=c.execute('SELECT * FROM users WHERE username=?',(request.form['username'],)).fetchone()
  if u and hmac.compare_digest(hashpw(request.form['password'],u['salt']),u['password_hash']):
   session.clear();session['company_id']=u['company_id'];session['user_id']=u['id'];session.permanent=True;return redirect('/')
  return 'Invalid login',401
 return page('Sign in','''<div class="card"><form method="post"><input type="hidden" name="csrf" value="{{csrf}}"><input name="username" placeholder="Username" required><input type="password" name="password" placeholder="Password" required><button>Sign in</button></form></div>''')
@app.route('/logout')
def logout():session.clear();return redirect('/login')
@app.route('/')
def home():
 with conn() as c:
  n=c.execute('SELECT COUNT(*) FROM customers WHERE company_id=?',(current(),)).fetchone()[0]
  j=c.execute('SELECT COUNT(*) FROM jobs WHERE company_id=?',(current(),)).fetchone()[0]
  company=c.execute('SELECT name FROM companies WHERE id=?',(current(),)).fetchone()['name']
 return page('Dashboard',f'<div class="card"><h2>{__import__("markupsafe").escape(company)}</h2><p>Customers: {n} &nbsp; | &nbsp; Jobs: {j}</p><p>Version 1 foundation — estimates, invoices, scheduling and reports are planned for later releases.</p></div>')
@app.route('/customers',methods=['GET','POST'])
def customers():
 if request.method=='POST':
  name=request.form['name'].strip()
  if not name:return 'Name required',400
  with conn() as c:c.execute('INSERT INTO customers(company_id,name,email,phone,notes,created_at) VALUES(?,?,?,?,?,?)',(current(),name,request.form.get('email',''),request.form.get('phone',''),request.form.get('notes',''),datetime.now(timezone.utc).isoformat()))
  return redirect('/customers')
 with conn() as c:rows=c.execute('SELECT * FROM customers WHERE company_id=? ORDER BY id DESC',(current(),)).fetchall()
 body='''<div class="card"><h3>Add customer</h3><form method="post"><input type="hidden" name="csrf" value="{{csrf}}"><input name="name" placeholder="Customer name" required><input name="email" placeholder="Email"><input name="phone" placeholder="Phone"><input name="notes" placeholder="Notes"><button>Add</button></form></div><div class="card"><table><tr><th>Name</th><th>Email</th><th>Phone</th></tr>'''
 for r in rows:
  from markupsafe import escape
  body+=f'<tr><td>{escape(r["name"])}</td><td>{escape(r["email"] or "")}</td><td>{escape(r["phone"] or "")}</td></tr>'
 return page('Customers',body+'</table></div>')
@app.route('/jobs',methods=['GET','POST'])
def jobs():
 if request.method=='POST':
  with conn() as c:
   customer=c.execute('SELECT id FROM customers WHERE id=? AND company_id=?',(request.form['customer_id'],current())).fetchone()
   if not customer:abort(400)
   c.execute('INSERT INTO jobs(company_id,customer_id,title,status,amount,created_at) VALUES(?,?,?,?,?,?)',(current(),customer['id'],request.form['title'].strip(),'Planned',float(request.form.get('amount') or 0),datetime.now(timezone.utc).isoformat()))
  return redirect('/jobs')
 with conn() as c:
  cs=c.execute('SELECT id,name FROM customers WHERE company_id=?',(current(),)).fetchall()
  js=c.execute('SELECT jobs.title,jobs.status,jobs.amount,customers.name FROM jobs JOIN customers ON jobs.customer_id=customers.id WHERE jobs.company_id=? ORDER BY jobs.id DESC',(current(),)).fetchall()
 from markupsafe import escape
 opts=''.join(f'<option value="{x["id"]}">{escape(x["name"])}</option>' for x in cs)
 body=f'''<div class="card"><form method="post"><input type="hidden" name="csrf" value="{{{{csrf}}}}"><select name="customer_id" required>{opts}</select><input name="title" placeholder="Job title" required><input type="number" step="0.01" min="0" name="amount" placeholder="Estimated amount"><button>Add job</button></form></div><div class="card"><table><tr><th>Job</th><th>Customer</th><th>Status</th><th>Amount</th></tr>'''
 for j in js:body+=f'<tr><td>{escape(j["title"])}</td><td>{escape(j["name"])}</td><td>{escape(j["status"])}</td><td>${j["amount"]:,.2f}</td></tr>'
 return page('Jobs',body+'</table></div>')
@app.route('/backup',methods=['GET','POST'])
def backup():
 if request.method=='POST':
  folder=BASE/'backups';folder.mkdir(exist_ok=True)
  target=folder/('nexus_crm_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')+'.sqlite3')
  with conn() as src, sqlite3.connect(target) as dst:src.backup(dst)
  return send_file(target,as_attachment=True,download_name=target.name)
 return page('Database backup','''<div class="card"><p>Create a consistent SQLite database snapshot and download it to a safe location. Backup files contain customer data and password hashes; protect them.</p><form method="post"><input type="hidden" name="csrf" value="{{csrf}}"><button>Create & download backup</button></form></div>''')
from features import install as install_features
install_features(app,conn,current,page)
from upgrade12 import install as install_upgrade12
install_upgrade12(app,conn,current,page,hashpw,BASE)
from upgrade13 import install as install_upgrade13
install_upgrade13(app,conn,current,page,BASE)
from upgrade14 import install as install_upgrade14
install_upgrade14(app,conn,current,page,BASE)
from upgrade15 import install as install_upgrade15
install_upgrade15(app,conn,current,page,DATA)
from upgrade16 import install as install_upgrade16
install_upgrade16(app,conn,current,page,DATA)
from upgrade20 import install as install_upgrade20
install_upgrade20(app,conn,current,page,DATA)
from upgrade21 import install as install_upgrade21
install_upgrade21(app,conn,current,page)
if __name__=='__main__':
 print('Open http://127.0.0.1:8765')
 app.run(host='127.0.0.1',port=8765,debug=False)
